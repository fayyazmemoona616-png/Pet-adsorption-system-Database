CREATE DATABASE PetAdoptionSystem;

CREATE TABLE Users (
    userID INT AUTO_INCREMENT PRIMARY KEY,
    Name VARCHAR(255) NOT NULL,
    Email VARCHAR(100) NOT NULL UNIQUE,
    Password VARCHAR(255) NOT NULL,
    Address TEXT,
    Contact_No INT,
    Role VARCHAR(255) NOT NULL
);


CREATE TABLE Adopter (
    ID INT AUTO_INCREMENT PRIMARY KEY,
    userID INT NOT NULL,
    FOREIGN KEY (userID) REFERENCES Users(userID) ON DELETE CASCADE
);


CREATE TABLE Shelter (
    ID INT AUTO_INCREMENT PRIMARY KEY,
    userID INT NOT NULL,
    FOREIGN KEY (userID) REFERENCES Users(userID) ON DELETE CASCADE
);

CREATE TABLE Pets (
    petID INT AUTO_INCREMENT PRIMARY KEY,  
    species VARCHAR(100) NOT NULL,         
    age VARCHAR(100),                              
    breed VARCHAR(100),                   
    gender VARCHAR(10),                   
    temperament VARCHAR(100),            
    description TEXT,                     
    shelterID INT,                        
    FOREIGN KEY (shelterID) REFERENCES Shelter(ID)  
);

CREATE TABLE AdoptionRequests (
    requestID INT AUTO_INCREMENT PRIMARY KEY,   
    adopterID INT,                              
    petID INT,                                 
    adoptionDate DATE,                          
    FOREIGN KEY (adopterID) REFERENCES Adopter(ID),  
    FOREIGN KEY (petID) REFERENCES Pets(petID)      
);



CREATE TABLE MedicalRecords (
    recordID INT AUTO_INCREMENT PRIMARY KEY,   
    petID INT,                                 
    vaccineStatus VARCHAR(255),                 
    allergies TEXT,                           
    healthIssues TEXT,                         
    treatmentHistory TEXT,                    
    FOREIGN KEY (petID) REFERENCES Pets(petID) 
);
