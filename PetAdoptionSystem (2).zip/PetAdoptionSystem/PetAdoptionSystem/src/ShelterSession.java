/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Hp
 */
// Example session management class
public class ShelterSession {
    private static int loggedInShelterID = -1;  // Default to -1, meaning no shelter is logged in

    // Method to set the logged-in shelter ID
    public static void setLoggedInShelterID(int shelterID) {
        loggedInShelterID = shelterID;
    }

  // Method to get the logged-in shelter ID
    public static int getLoggedInShelterID() {
        return loggedInShelterID;
    }
}

