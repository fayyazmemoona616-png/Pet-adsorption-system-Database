/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
/**
 *
 * @author Hp
 */
public class NewMain {
    public static void main(String[] args) {
        Connection conn = Connector.getConnection();
        if (conn != null) {
            System.out.println("Connection is successful!");
        }
    }
}

