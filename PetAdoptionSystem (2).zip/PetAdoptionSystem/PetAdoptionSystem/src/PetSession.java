/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Hp
 */
public class PetSession {
    // Static variable to store the petID
    private static int petID = -1;

    // Method to set the petID
    public static void setPetID(int id) {
        petID = id;
    }

    // Method to get the petID
    public static int getPetID() {
        return petID;
    }
}

